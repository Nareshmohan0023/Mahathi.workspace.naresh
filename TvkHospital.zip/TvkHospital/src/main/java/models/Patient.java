package models;

public class Patient {
	
	private  int patId;
	private  String patName;
	private  String patIll;
	
	public int getPatId() {
		return patId;
	}
	public void setPatId(int patId) {
		this.patId = patId;
	}
	public String getPatName() {
		return patName;
	}
	public void setPatName(String patName) {
		this.patName = patName;
	}
	public String getPatIll() {
		return patIll;
	}
	public void setPatIll(String patIll) {
		this.patIll = patIll;
	}
	
	
	
}
