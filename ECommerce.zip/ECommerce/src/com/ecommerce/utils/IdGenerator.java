package com.ecommerce.utils;

import com.ecommerce.db.DataBase;

public class IdGenerator {
	private static int counter = 0;

	public static String CATIdGenerator(String code) {
		counter++;
		return code + String.format("%03d", counter);
	}

	public static int productIdGenerator() {
		int num = DataBase.getProdustsList().size();
		num++;
		return num;
	}
	
	public static int customerIdGenerator() {
		int num = DataBase.getCustomerList().size();
		num++;
		return num;
	}

}
