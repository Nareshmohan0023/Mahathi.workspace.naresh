package com.ecommerce.entity;

import java.util.ArrayList;
import java.util.List;

public class Cart {
	private List<CartItem> cart=new ArrayList<>();
	

	public List<CartItem> getCart() {
		return cart;
	}

	public void setCart(List<CartItem> cart) {
		this.cart = cart;
	}
	
	
}
