package com.ecommerce.service;

import com.ecommerce.entity.Customer;

public interface CustomerService {
	void addCustomer(Customer customer);
	void displayCustomer();
	boolean customerValidation(String name);
}
